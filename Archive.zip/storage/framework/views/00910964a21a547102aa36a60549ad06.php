<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href', 'current' => false, 'ariaCurrent' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href', 'current' => false, 'ariaCurrent' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    // $classes = $current ? 'bg-gray-950/50 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white';
if ($current) {
    $classes = 'bg-gray-950/50 text-white';
    $ariaCurrent = 'page';
} else {
    $classes = 'text-gray-300 hover:bg-white/5 hover:text-white';
}
?>
<a href="<?php echo e($href); ?>" 
<?php echo e($attributes->merge(['class' => 'rounded-md px-3 py-2 text-sm font-medium ' . $classes, 'aria-current' => $ariaCurrent])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH /Users/bolong/newblog/resources/views/components/my-nav-link.blade.php ENDPATH**/ ?>