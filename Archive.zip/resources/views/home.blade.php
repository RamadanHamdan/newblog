<x-layout :title="$title">
          <h2>Welcome to Homepage</h2>
          <p>This is the home page of our Laravel application.</p>
</x-layout>
