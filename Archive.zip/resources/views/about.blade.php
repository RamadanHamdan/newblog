<x-layout :title="$title">
<p>isinya cinta caca semua</p>
</x-layout>