<x-layout :title="$title">
    <p>This is Contact Page</p>
</x-layout>